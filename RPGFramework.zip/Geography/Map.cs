﻿namespace RPGFramework.Geography
{
    // We'll use this to create display information for the map.
    // TODO!
    internal class Map
    {
    }
}
