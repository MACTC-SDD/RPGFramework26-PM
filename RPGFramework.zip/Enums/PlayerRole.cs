﻿
namespace RPGFramework.Enums
{
    internal enum PlayerRole
    {
        Player,
        Admin,
        God
    }
}
