﻿
namespace RPGFramework
{
    internal class Armor : Item
    {
        // TODO - Implement once we know how combat will work
    }
}
